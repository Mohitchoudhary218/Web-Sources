


document.getElementById("b2").addEventListener("mouseover", color);

function color()
{
    document.getElementById("b2").setAttribute("style", "color: grey");
}
export interface bookCourtGet {
    id:number;
    reservationArea: string;
    firstName: string;
    lastName: string;
    userId:string;
    personCount: number;
    reservationHours: number;
    appointmentTime: string;
    userCode:string;

  }
export interface authGet {
    id:number;
    userId:string;
    password:string;
    userCode:string
  }
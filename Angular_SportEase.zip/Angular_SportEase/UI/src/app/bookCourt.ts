export interface bookCourt {
    reservationArea: string;
    firstName: string;
    lastName: string;
    userId:string;
    personCount: number;
    reservationHours: number;
    appointmentTime: string
  }
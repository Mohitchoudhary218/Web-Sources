export interface auth {
    userId:string;
    password:string
  }
package tech.SportEase.model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
@Entity
public class bookCourt implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, updatable = false)
    private Long id;
    private String reservationArea;
    private String firstName;
    private String lastName;

    private String userId;
    private int personCount;
    private int reservationHours;
    private LocalDateTime appointmentTime;

    @Column(nullable = false, updatable = false)
    private String UserCode;

    public bookCourt() {}

    public bookCourt(String reservationArea, String firstName, String lastName, String userId, int personCount, int reservationHours, LocalDateTime appointmentTime) {
        this.reservationArea = reservationArea;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userId = userId;
        this.personCount = personCount;
        this.reservationHours = reservationHours;
        this.appointmentTime = appointmentTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReservationArea() {
        return reservationArea;
    }

    public void setReservationArea(String reservationArea) {
        this.reservationArea = reservationArea;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserId() { return userId; }

    public void setUserId(String userId) { this.userId = userId; }

    public int getPersonCount() {
        return personCount;
    }

    public void setPersonCount(int personCount) {
        this.personCount = personCount;
    }

    public int getReservationHours() {
        return reservationHours;
    }

    public void setReservationHours(int reservationHours) {
        this.reservationHours = reservationHours;
    }

    public LocalDateTime getAppointmentTime() {
        return appointmentTime;
    }
    public void setAppointmentTime(LocalDateTime appointmentTime) {
        this.appointmentTime = appointmentTime;
    }
    public String getUserCode() {
        return UserCode;
    }

    public void setUserCode(String UserCode) {
        this.UserCode = UserCode;
    }

    @Override
    public String toString() {
        return "bookCourt{" +
                "id=" + id +
                ", area='" + reservationArea + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", userId='" + userId + '\'' +
                ", personCount='" + personCount + '\'' +
                ", reservationHours='" + reservationHours + '\'' +
                ", appointmentTime='" + appointmentTime + '\'' +
                '}';
    }
}

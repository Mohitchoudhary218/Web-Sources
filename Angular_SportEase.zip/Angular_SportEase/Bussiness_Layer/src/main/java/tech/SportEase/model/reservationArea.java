package tech.SportEase.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class reservationArea implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, updatable = false)
    private Long id;
    private String area;
    private String name;
    private int rating;
    private String location;
    private String sport;
    private int availability;
    private int rate;
    private String country;
    private String province;
    private String city;
    private String link;

    @Column(nullable = false, updatable = false)
    private String UserCode;

    public reservationArea() {}

    public reservationArea(String area, String name, int rating, String location, String sport, int availability, int rate, String country, String province, String city, String link) {
        this.area = area;
        this.name = name;
        this.rating = rating;
        this.location = location;
        this.sport = sport;
        this.availability = availability;
        this.rate = rate;
        this.country = country;
        this.province = province;
        this.city = city;
        this.link = link;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public int getAvailability() {
        return availability;
    }
    public void setAvailability(int availability) {
        this.availability = availability;
    }

    public int getRate() {
        return rate;
    }
    public void setRate(int rate) {
        this.rate = rate;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getProvince() {
        return province;
    }
    public void setProvince(String province) {
        this.province = province;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }
    public String getUserCode() {
        return UserCode;
    }

    public void setUserCode(String UserCode) {
        this.UserCode = UserCode;
    }

    @Override
    public String toString() {
        return "reservationArea{" +
                "id=" + id +
                ", area='" + area + '\'' +
                ", name='" + name + '\'' +
                ", rating='" + rating + '\'' +
                ", location='" + location + '\'' +
                ", sport='" + sport + '\'' +
                ", availability='" + availability + '\'' +
                ", rate='" + rate + '\'' +
                ", country='" + country + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", link='" + link + '\'' +
                '}';
    }
}

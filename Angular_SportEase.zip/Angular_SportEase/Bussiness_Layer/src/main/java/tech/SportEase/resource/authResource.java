package tech.SportEase.resource;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.SportEase.model.authentication;
import tech.SportEase.service.authenticationService;

import java.util.List;

@RestController
@RequestMapping("/auth")
public class authResource {

    private final authenticationService authService;

    public authResource(authenticationService authService) {
        this.authService = authService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<authentication>> getAllAuth () {
        List<authentication> auth = authService.findAllAuth();
        return new ResponseEntity<>(auth, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<authentication> getAuthById (@PathVariable("id") Long id) {
        authentication auth = authService.findAuthById(id);
        return new ResponseEntity<>(auth, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<authentication> addAuth(@RequestBody authentication auth) {
        authentication auths = authService.addAuth(auth);
        return new ResponseEntity<>(auths, HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<authentication> updateAuth(@RequestBody authentication auth) {
        authentication auths = authService.updateAuth(auth);
        return new ResponseEntity<>(auths, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteAuth(@PathVariable("id") Long id) {
        authService.deleteAuth(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}

package tech.SportEase.resource;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.SportEase.service.bookCourtService;
import tech.SportEase.model.bookCourt;

import java.util.List;

@RestController
@RequestMapping("/book")
public class bookResource {
    private final bookCourtService bookService;

    public bookResource(bookCourtService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<bookCourt>> getAllBook () {
        List<bookCourt> bookings = bookService.findAllBookings();
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    /* @GetMapping("/find/{id}")
    public ResponseEntity<reservationArea> getAreasById (@PathVariable("id") Long id) {
        reservationArea area = areaService.findAreasById(id);
        return new ResponseEntity<>(area, HttpStatus.OK);
    }*/

    @PostMapping("/add")
    public ResponseEntity<bookCourt> addBook(@RequestBody bookCourt book) {
        bookCourt books = bookService.addBook(book);
        return new ResponseEntity<>(books, HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<bookCourt> updateBook(@RequestBody bookCourt book) {
        bookCourt books = bookService.updateBook(book);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable("id") Long id) {
        bookService.deleteBook(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}

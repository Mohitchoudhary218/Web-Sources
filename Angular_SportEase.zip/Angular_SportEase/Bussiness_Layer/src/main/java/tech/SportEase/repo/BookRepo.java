package tech.SportEase.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.SportEase.model.bookCourt;

import java.util.Optional;

public interface BookRepo extends JpaRepository<bookCourt, Long> {
    void deleteBookById(Long id);

    Optional<bookCourt> findBookById(Long id);
}

package tech.SportEase.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tech.SportEase.repo.BookRepo;
import tech.SportEase.exception.UserNotFoundException;
import tech.SportEase.model.bookCourt;

import javax.transaction.Transactional;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class bookCourtService {
    private final BookRepo bookRepo;

    @Autowired
    public bookCourtService(BookRepo bookRepo) {
        this.bookRepo = bookRepo;
    }

    public bookCourt addBook(bookCourt book) {
        book.setUserCode(UUID.randomUUID().toString());
        return bookRepo.save(book);
    }

    public List<bookCourt> findAllBookings() {
        return bookRepo.findAll();
    }

    public bookCourt updateBook(bookCourt book) {
        return bookRepo.save(book);
    }

    public bookCourt findBookById(Long id) {
        return bookRepo.findBookById(id)
                .orElseThrow(() -> new UserNotFoundException("User by id " + id + " was not found"));
    }
    public void deleteBook(Long id){
        bookRepo.deleteBookById(id);
    }
}
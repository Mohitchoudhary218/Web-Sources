package tech.SportEase.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tech.SportEase.model.reservationArea;
import tech.SportEase.exception.UserNotFoundException;
import tech.SportEase.repo.AreaRepo;

import javax.transaction.Transactional;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class reservationAreaService {
    private final AreaRepo areaRepo;

    @Autowired
    public reservationAreaService(AreaRepo areaRepo) {
        this.areaRepo = areaRepo;
    }

    public reservationArea addArea(reservationArea area) {
        area.setUserCode(UUID.randomUUID().toString());
        return areaRepo.save(area);
    }


    public List<reservationArea> findAllAreas() {
        return areaRepo.findAll();
    }


    public reservationArea updateArea(reservationArea area) {
        return areaRepo.save(area);
    }
    public reservationArea findAreasById(Long id) {
        return areaRepo.findAreasById(id)
                .orElseThrow(() -> new UserNotFoundException("User by id " + id + " was not found"));
    }
    public void deleteArea(Long id){
        areaRepo.deleteAreaById(id);
    }

}

package tech.SportEase.resource;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.SportEase.model.reservationArea;
import tech.SportEase.service.reservationAreaService;

import java.util.List;

@RestController
@RequestMapping("/area")
public class areaResource {
    private final reservationAreaService areaService;

    public areaResource(reservationAreaService areaService) {
        this.areaService = areaService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<reservationArea>> getAllAreas () {
        List<reservationArea> areas = areaService.findAllAreas();
        return new ResponseEntity<>(areas, HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<reservationArea> getAreasById (@PathVariable("id") Long id) {
        reservationArea area = areaService.findAreasById(id);
        return new ResponseEntity<>(area, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<reservationArea> addArea(@RequestBody reservationArea area) {
        reservationArea areas = areaService.addArea(area);
        return new ResponseEntity<>(areas, HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<reservationArea> updateAreas(@RequestBody reservationArea area) {
        reservationArea updateAreas = areaService.updateArea(area);
        return new ResponseEntity<>(updateAreas, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteArea(@PathVariable("id") Long id) {
        areaService.deleteArea(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}

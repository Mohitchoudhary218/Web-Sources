package tech.SportEase.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tech.SportEase.exception.UserNotFoundException;
import tech.SportEase.model.authentication;
import tech.SportEase.repo.AuthRepo;

import javax.transaction.Transactional;
import java.util.List;
import java.util.UUID;

@Service
@Transactional

public class authenticationService {


    private final AuthRepo authRepo;

    @Autowired
    public authenticationService(AuthRepo authRepo) {
        this.authRepo = authRepo;
    }

    public authentication addAuth(authentication area) {
        area.setUserCode(UUID.randomUUID().toString());
        return authRepo.save(area);
    }


    public List<authentication> findAllAuth() {
        return authRepo.findAll();
    }


    public authentication updateAuth(authentication auth) {
        return authRepo.save(auth);
    }
    public authentication findAuthById(Long id) {
        return authRepo.findAuthById(id)
                .orElseThrow(() -> new UserNotFoundException("User by id " + id + " was not found"));
    }
    public void deleteAuth(Long id){
        authRepo.deleteAuthById(id);
    }

}

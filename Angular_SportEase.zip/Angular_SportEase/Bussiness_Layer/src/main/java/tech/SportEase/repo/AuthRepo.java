package tech.SportEase.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.SportEase.model.authentication;

import java.util.Optional;

public interface AuthRepo extends JpaRepository<authentication, Long> {
    void deleteAuthById(Long id);

    Optional<authentication> findAuthById(Long id);
}

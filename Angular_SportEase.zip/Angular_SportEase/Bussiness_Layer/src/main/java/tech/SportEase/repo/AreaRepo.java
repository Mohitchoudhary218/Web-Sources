package tech.SportEase.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.SportEase.model.reservationArea;

import java.util.Optional;

public interface AreaRepo extends JpaRepository<reservationArea, Long> {
    void deleteAreaById(Long id);

    Optional<reservationArea> findAreasById(Long id);
}

